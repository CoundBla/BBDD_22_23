# Hito 3: Programación contra bases de datos (Hibernate)

Este proyecto contiene la plantilla de código fuente para realizar el Apartado 2 del Hito 3 (Programación contra bases de datos) de la asignatura de Bases de Datos en el Curso Académico 2022-2023. Podrás encontrar más información sobre la misma en el Moodle de la asignatura.

*ETSI de Sistemas Informáticos | Universidad Politécnica de Madrid*

