package ormExpressCorreos.model;

// @TODO completar las anotaciones de la clase
public class UsuarioIdentificado {
    
    // @TODO completar las anotaciones de todos los atributos

    public UsuarioIdentificado(String DNI, String nombre, String apellidos, String email, ...) {  // @TODO: completar
        // @TODO completar el constructor de la clase.
        //  Para ello son necesarios strings con el DNI, el nombre, los apellidos y el email del usuario
        //  Cree e inicialice el resto de atributos a los valores que considere oportunos
    }

    public String getDNI() {
        return this.DNI;
    }

    public String getNombre() {
        return this.nombre;
    }

    public String getApellidos() {
        return this.apellidos;
    }

    public String getEmail() {
        return this.email;
    }
}
